
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class main {

    public static void main(String[] args) throws InterruptedException, IOException {
        Random random = new Random(System.currentTimeMillis());

        int teamAPanelties = 0;
        int teamBPanelties = 0;

        players teamA[] = new players[11];
        players teamB[] = new players[11];
        ball ballobj = new ball();
        ballobj.setDiameter((float) 0.22);

        ground groundobj = new ground();
        groundobj.setLength(120);
        groundobj.setWidth(90);

        goalkeeper goalKeeper = new goalkeeper();
        goalKeeper.probabilityToCatch = 75;

        for (int i = 0; i < 11; i++) {
            teamA[i] = new players();
            teamB[i] = new players();

            // setting the player information in the player objects
            teamA[i].setName("player " + i);
            teamA[i].setTeam("teamA");
            teamA[i].setProbabilityToMakePass(random.nextInt(50) + 30);
            teamA[i].setProbabilityToMakeGoal(random.nextInt(16));

            teamB[i].setName("player " + i);
            teamB[i].setTeam("teamB");
            teamB[i].setProbabilityToMakePass(random.nextInt(50) + 30);
            teamB[i].setProbabilityToMakeGoal(random.nextInt(16));

        }
        int time = 0;
        int timeOverall = 0;
        moveCursor(1, 5);
        System.out.println("First Half");

        Thread.sleep(3000);
        clearScreen();

        players currentPlayer = new players();

        // choose first team to get the ball using toss
        boolean toss = random.nextFloat() < 0.5;
        if (toss)
            currentPlayer = teamA[random.nextInt(11)];
        else
            currentPlayer = teamB[random.nextInt(11)];
        int teamAGoals = 0;
        int teamBGoals = 0;
        int playingTime = 90;
        boolean isPanelty = false;


        while (true) {
            boolean ballGoesOut = random.nextFloat() < ballobj.diameter * 1000 / groundobj.groundArea();
            boolean isPassed = random.nextFloat() < 0.6;
            boolean passToSameTeam = random.nextFloat() * 100 < currentPlayer.probabilityToMakePass;
            boolean makeGoal = random.nextFloat() * 100 < currentPlayer.probabilityToMakeGoal;
            if (!ballGoesOut) {
                if (makeGoal) {
                    if (currentPlayer.team == "teamA")
                        teamAGoals++;
                    else
                        teamBGoals++;

                } else if (isPassed) {
                    if (passToSameTeam) {
                        if (currentPlayer.team == "teamA")
                            currentPlayer = teamA[random.nextInt(11)];
                        else
                            currentPlayer = teamB[random.nextInt(11)];
                    } else {
                        if (currentPlayer.team == "teamB")
                            currentPlayer = teamA[random.nextInt(11)];
                        else
                            currentPlayer = teamB[random.nextInt(11)];

                    }
                }
            } else {
                // ball goes out
                moveCursor(8, 20);
                System.out.print("Ball goes Out");
                for (int k = 0; k < 10; k++) {
                    System.out.print(".");
                    Thread.sleep(100);
                }
                clearScreen();

            }

            moveCursor(1, 1);
            System.out.print("Time ");
            System.out.print(time + "\r");
            moveCursor(3, 1);
            System.out.print("player name");
            moveCursor(5, 1);
            if (currentPlayer.name.length() < 9) {
                System.out.print(" " + currentPlayer.name);

            } else {
                System.out.print(currentPlayer.name);
            }

            moveCursor(3, 20);

            System.out.print("player team");
            moveCursor(5, 20);
            System.out.print(currentPlayer.team);

            moveCursor(3, 40);
            System.out.print("TeamA points");
            moveCursor(5, 40);
            System.out.print(teamAGoals);
            moveCursor(3, 55);
            System.out.print("TeamB points");
            moveCursor(5, 55);
            System.out.print(teamBGoals);
            deleteLine(5);
            if (timeOverall == 105) {
                if (teamAGoals != teamBGoals) {
                    clearScreen();
                    if (teamAGoals > teamBGoals) {
                        System.out.println("Team A wins");
                        Thread.sleep(5000);

                    } else {
                        System.out.println("Team B wins");
                        Thread.sleep(5000);

                    }

                } else {
                    isPanelty = true;
                    break;
                }

            }

            if (timeOverall >= playingTime && playingTime != 105) {

                if (teamAGoals == teamBGoals) {

                    playingTime = 105;
                    time = 0;
                    clearScreen();
                    System.out.print("Extra Time....");
                    Thread.sleep(3000);

                } else {
                    clearScreen();
                    if (teamAGoals > teamBGoals) {
                        System.out.println("Team A wins");
                        Thread.sleep(5000);

                    } else {
                        System.out.println("Team B wins");
                        Thread.sleep(5000);

                    }

                    break;
                }
            }

            time++;
            timeOverall++;
            if (timeOverall == 45) {
                clearScreen();
                System.out.println("BREAK TIME");
                time = 0;
                for (int j = 1; j < 16; j++) {
                    System.out.print("Time ");
                    System.out.print(time + "\r");
                    Thread.sleep(1000);
                    time++;
                }
                time = 0;
                clearScreen();
                moveCursor(2, 2);
                System.out.println("Second Half");
                Thread.sleep(3000);

                clearScreen();

            }
            Thread.sleep(1000);

        }
        if (isPanelty) {
           
            boolean paneltyTeam = random.nextFloat() < 0.5;
            clearScreen();
            System.out.println("penalties");
            Thread.sleep(1000);
            boolean ballCatched = random.nextFloat() * 250 < goalKeeper.probabilityToCatch;

            moveCursor(3, 3);
            System.out.print("teamA - 0");
            moveCursor(5, 3);
            System.out.print("teamB - 0");

            for (int i = 0; i < 5; i++) {
                if (!ballCatched) {
                    if (paneltyTeam) {
                        teamAPanelties++;
                        moveCursor(3, 3);
                        System.out.print("teamA - " + teamAPanelties);
                    } else {
                        teamBPanelties++;
                        moveCursor(5, 3);
                        System.out.print("teamB - " + teamBPanelties);
                    }
                }
                Thread.sleep(1000);
            }

           
            if (paneltyTeam)
                paneltyTeam = false;
            else
                paneltyTeam = true;
            for (int i = 0; i < 5; i++) {
                if (!ballCatched){
                    if (paneltyTeam) {
                        teamAPanelties++;
                        moveCursor(3, 3);
                        System.out.print("teamA - " + teamAPanelties);
                    } else {
                        teamBPanelties++;
                        moveCursor(5, 3);
                        System.out.print("teamB - " + teamBPanelties);
                    }
                }
                Thread.sleep(1000);

            }
           


        }

        clearScreen();
        if(teamAPanelties>teamBPanelties){
            System.out.println("TeamA wins");
            Thread.sleep(2000);
        }else{
            System.out.println("TeamB wins");
            Thread.sleep(2000);
        }
        System.out.println("Game Over");

    }

    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public static void moveCursor(int rowp, int columnp) {
        char escCode = 0x1B;
        int row = rowp;
        int column = columnp;
        System.out.print(String.format("%c[%d;%df", escCode, row, column));

    }

    public static void deleteLine(int getLine) {
        int count = getLine;
        System.out.print(String.format("\033[%dA", count)); // Move up
        System.out.print("\033[2K"); // Erase line content
    }

}

class players {
    public String name = "";
    public String team = "";
    public int probabilityToMakeGoal;
    public int probabilityToMakePass;

    public void setName(String namePassed) {
        name = namePassed;
    }

    public void setTeam(String teamPassed) {
        team = teamPassed;
    }

    public void setProbabilityToMakeGoal(int probabilityPassed) {
        probabilityToMakeGoal = probabilityPassed;
    }

    public void setProbabilityToMakePass(int probabilityPassed) {
        probabilityToMakePass = probabilityPassed;
    }
}

class goalkeeper {
    public int probabilityToCatch;
}

class goal {
    private float height;
    private float width;

    public void setHeight(float heightPassed) {
        height = heightPassed;
    }

    public void setWidth(float widthPassed) {
        width = widthPassed;
    }
}

class ground {
    private float length;
    private float width;

    public void setLength(float lengthPassed) {
        length = lengthPassed;
    }

    public void setWidth(float widthPassed) {
        width = widthPassed;
    }

    public float groundArea() {
        return length * width;
    }
}

class ball {
    public float diameter;

    public void setDiameter(float diameterPassed) {
        diameter = diameterPassed;
    }

}
